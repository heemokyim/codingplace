﻿from distutils.core import setup

setup(
	name='settingr',
	py_modules=['sketch']
)